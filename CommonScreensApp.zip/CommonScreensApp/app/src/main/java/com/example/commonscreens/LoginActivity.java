package com.example.commonscreens;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity {

    private TextInputLayout tilUser, tilPassword;
    private TextInputEditText etUser, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        tilUser = findViewById(R.id.tilUser);
        tilPassword = findViewById(R.id.tilPassword);
        etUser = findViewById(R.id.etUser);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnRegister = findViewById(R.id.btnRegister);
        TextView tvForgot = findViewById(R.id.tvForgot);

        btnLogin.setOnClickListener(v -> attemptLogin());

        btnRegister.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class)));

        tvForgot.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class)));
    }

    private void attemptLogin() {
        tilUser.setError(null);
        tilPassword.setError(null);

        String user = etUser.getText() == null ? "" : etUser.getText().toString().trim();
        String pass = etPassword.getText() == null ? "" : etPassword.getText().toString();

        boolean valid = true;
        if (user.isEmpty()) {
            tilUser.setError(getString(R.string.err_empty));
            valid = false;
        }
        if (pass.isEmpty()) {
            tilPassword.setError(getString(R.string.err_empty));
            valid = false;
        }
        if (!valid) return;

        if (AuthStore.login(user, pass)) {
            Toast.makeText(this, R.string.msg_login_ok, Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
            intent.putExtra("email", AuthStore.resolveEmail(user));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        } else {
            tilPassword.setError(getString(R.string.err_invalid_login));
        }
    }
}
