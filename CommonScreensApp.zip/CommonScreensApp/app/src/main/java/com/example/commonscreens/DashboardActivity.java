package com.example.commonscreens;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        email = getIntent().getStringExtra("email");
        if (email == null) email = AuthStore.DEFAULT_EMAIL;

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        tvWelcome.setText(getString(R.string.dashboard_welcome, AuthStore.getName(email)));

        bindModule(R.id.cardCourses, R.string.module_courses);
        bindModule(R.id.cardSchedule, R.string.module_schedule);
        bindModule(R.id.cardGrades, R.string.module_grades);
        bindModule(R.id.cardMessages, R.string.module_messages);
        bindModule(R.id.cardLibrary, R.string.module_library);

        // Profile card -> explicit Intent to ProfileActivity
        findViewById(R.id.cardProfile).setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ProfileActivity.class);
            intent.putExtra("email", email);
            startActivity(intent);
        });
    }

    private void bindModule(int cardId, int nameRes) {
        View card = findViewById(cardId);
        card.setOnClickListener(v -> Toast.makeText(this,
                getString(R.string.msg_module_open, getString(nameRes)),
                Toast.LENGTH_SHORT).show());
    }
}
