package com.example.commonscreens;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Hard-coded, in-memory "database" used to simulate authentication.
 * No backend is required for this assignment.
 */
public final class AuthStore {

    public static final String DEFAULT_EMAIL = "admin@test.com";
    public static final String DEFAULT_PASSWORD = "123456";

    // email -> password
    private static final Map<String, String> PASSWORDS = new HashMap<>();
    // email -> full name
    private static final Map<String, String> NAMES = new HashMap<>();

    static {
        PASSWORDS.put(DEFAULT_EMAIL, DEFAULT_PASSWORD);
        NAMES.put(DEFAULT_EMAIL, "Admin User");
    }

    private AuthStore() { }

    public static boolean isValidEmail(String email) {
        return email != null && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public static boolean login(String emailOrUser, String password) {
        String key = emailOrUser.trim().toLowerCase();
        if (key.equals("admin")) key = DEFAULT_EMAIL; // allow username "admin"
        String saved = PASSWORDS.get(key);
        return saved != null && saved.equals(password);
    }

    public static void register(String name, String email, String password) {
        String key = email.trim().toLowerCase();
        PASSWORDS.put(key, password);
        NAMES.put(key, name.trim());
    }

    public static boolean emailExists(String email) {
        return PASSWORDS.containsKey(email.trim().toLowerCase());
    }

    public static void updatePassword(String email, String newPassword) {
        PASSWORDS.put(email.trim().toLowerCase(), newPassword);
    }

    public static String getName(String email) {
        String key = email.trim().toLowerCase();
        if (key.equals("admin")) key = DEFAULT_EMAIL;
        String name = NAMES.get(key);
        return name != null ? name : "User";
    }

    public static String resolveEmail(String emailOrUser) {
        String key = emailOrUser.trim().toLowerCase();
        return key.equals("admin") ? DEFAULT_EMAIL : key;
    }
}
