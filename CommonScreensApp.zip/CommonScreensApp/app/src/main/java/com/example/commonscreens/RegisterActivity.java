package com.example.commonscreens;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class RegisterActivity extends AppCompatActivity {

    private TextInputLayout tilName, tilEmail, tilPassword, tilConfirm;
    private TextInputEditText etName, etEmail, etPassword, etConfirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        tilName = findViewById(R.id.tilName);
        tilEmail = findViewById(R.id.tilEmail);
        tilPassword = findViewById(R.id.tilPassword);
        tilConfirm = findViewById(R.id.tilConfirm);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirm = findViewById(R.id.etConfirm);

        Button btnCreate = findViewById(R.id.btnCreate);
        Button btnBack = findViewById(R.id.btnBack);

        btnCreate.setOnClickListener(v -> attemptRegister());
        btnBack.setOnClickListener(v -> goToLogin());
    }

    private String text(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private void attemptRegister() {
        tilName.setError(null);
        tilEmail.setError(null);
        tilPassword.setError(null);
        tilConfirm.setError(null);

        String name = text(etName);
        String email = text(etEmail);
        String pass = etPassword.getText() == null ? "" : etPassword.getText().toString();
        String confirm = etConfirm.getText() == null ? "" : etConfirm.getText().toString();

        boolean valid = true;
        if (name.isEmpty()) {
            tilName.setError(getString(R.string.err_empty));
            valid = false;
        }
        if (email.isEmpty()) {
            tilEmail.setError(getString(R.string.err_empty));
            valid = false;
        } else if (!AuthStore.isValidEmail(email)) {
            tilEmail.setError(getString(R.string.err_email));
            valid = false;
        }
        if (pass.length() < 6) {
            tilPassword.setError(getString(R.string.err_password_len));
            valid = false;
        }
        if (!pass.equals(confirm)) {
            tilConfirm.setError(getString(R.string.err_password_match));
            valid = false;
        }
        if (!valid) return;

        AuthStore.register(name, email, pass);
        Toast.makeText(this, R.string.msg_register_ok, Toast.LENGTH_LONG).show();
        goToLogin();
    }

    private void goToLogin() {
        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}
