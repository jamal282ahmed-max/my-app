package com.example.commonscreens;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class ForgotPasswordActivity extends AppCompatActivity {

    private TextInputLayout tilEmail;
    private TextInputEditText etEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        tilEmail = findViewById(R.id.tilEmail);
        etEmail = findViewById(R.id.etEmail);
        Button btnSend = findViewById(R.id.btnSend);
        Button btnBack = findViewById(R.id.btnBack);

        btnSend.setOnClickListener(v -> sendRecovery());
        btnBack.setOnClickListener(v -> finish());
    }

    private void sendRecovery() {
        tilEmail.setError(null);
        String email = etEmail.getText() == null ? "" : etEmail.getText().toString().trim();

        if (email.isEmpty()) {
            tilEmail.setError(getString(R.string.err_empty));
            return;
        }
        if (!AuthStore.isValidEmail(email)) {
            tilEmail.setError(getString(R.string.err_email));
            return;
        }
        if (!AuthStore.emailExists(email)) {
            tilEmail.setError(getString(R.string.msg_email_unknown));
            return;
        }

        // Simulated recovery: no email is actually sent
        Toast.makeText(this, R.string.msg_recovery_sent, Toast.LENGTH_LONG).show();
        Intent intent = new Intent(ForgotPasswordActivity.this, ResetPasswordActivity.class);
        intent.putExtra("email", email);
        startActivity(intent);
    }
}
