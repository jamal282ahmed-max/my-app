# CampusHub – Android Common Screens (Java + XML)

Assignment 2 – Android Application Development.
A simple app that demonstrates the common screens found in most apps. Authentication is simulated locally (no backend).

## Implemented Features

| Screen | Activity | Layout | Features |
|---|---|---|---|
| Splash | `SplashActivity` | `activity_splash.xml` (ConstraintLayout) | Logo + app name, auto-navigates to Login after 2 s |
| Login | `LoginActivity` | `activity_login.xml` (LinearLayout) | Email/username + password, Login, Register, Forgot Password |
| Register | `RegisterActivity` | `activity_register.xml` | Name, email, password, confirm password with validation |
| Forgot Password | `ForgotPasswordActivity` | `activity_forgot_password.xml` | Email validation and simulated recovery |
| Reset Password | `ResetPasswordActivity` | `activity_reset_password.xml` | New + confirm password with validation |
| Dashboard | `DashboardActivity` | `activity_dashboard.xml` (GridLayout) | 6 module cards, each with icon and text |
| Profile | `ProfileActivity` | `activity_profile.xml` (ConstraintLayout) | User info and Logout |

## Technical Requirements Covered

- **Resources:** `strings.xml`, `colors.xml`, and alternative `values-night/colors.xml` for dark mode.
- **Layouts:** LinearLayout (Login, Register, Forgot/Reset), GridLayout (Dashboard), ConstraintLayout (Splash, Profile).
- **Input controls:** `textEmailAddress`, `textPassword` (with show/hide toggle), `textPersonName`.
- **Validation:** empty fields, email format, minimum 6-character password, password match.
- **Navigation:** explicit `Intent`s between all Activities.

## Navigation Flow

```
Splash -> Login -> Dashboard -> Profile -> (Logout) -> Login
            |-> Register -> (back to) Login
            |-> Forgot Password -> Reset Password -> Login
```

## Demo Credentials

- Email: `admin@test.com` (or username `admin`)
- Password: `123456`

## How to Run

1. Open the project in Android Studio (Hedgehog or newer).
2. Let Gradle sync, then run on an emulator or device (API 24+).
3. Toggle dark mode in device settings to see the night-mode colors.
